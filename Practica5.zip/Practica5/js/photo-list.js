const PHOTO_LIST = [
    'images/conejo.jpg',
    'images/gato.jpg',
    'images/lobo.jpg',
    'images/mono.jpg',
    'images/panda.jpg',
    'images/perro.jpeg',
    'images/suricata.jpg',
    'images/tigre.jpg',
    'images/zorro.jpg'
]